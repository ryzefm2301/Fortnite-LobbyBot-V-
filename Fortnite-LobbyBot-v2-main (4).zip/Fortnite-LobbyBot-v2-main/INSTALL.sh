#!/bin/bash
pip3 install -U pip
pip3 install -U --user -r requirements.txt
#!/bin/bash
python3 index.py -use-device-auth -use-authorization-code
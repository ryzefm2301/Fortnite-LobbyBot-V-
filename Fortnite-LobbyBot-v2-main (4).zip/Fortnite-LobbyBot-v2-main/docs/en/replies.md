## Replies
|  Key (Raw value)  |  Description  |
| ---- | ---- |
|  Run when (run_when)  |  Specify when replies will be runned  |
|  Apply prefixes to replies (prefix_to_replies)  |  Whether prefix is needed to run replies  |

### Replies (replies)
|  Key (Raw value)  |  Description  |
| ---- | ---- |
|  Match method (matchmethod)  |  Match method  |
|  Word (word)  |  Words to use for this reply  |
|  Reply (reply)  |  Message which reply  |
|  Cool time (ct)  |  Time until this reply has executed and it'll can be executed again  |

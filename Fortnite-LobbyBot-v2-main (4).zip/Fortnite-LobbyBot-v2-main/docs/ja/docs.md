## 詳細説明

### 用語集
説明内で言葉の定義がわからなかった場合に見てください  
[用語集](glossary.md "glossary.md")  

### コンフィグ
コンフィグに関する説明  
[コンフィグ](config.md "config.md")  

### コマンド
コマンドに関する説明  
[コマンド](commands.md "commands.md")  

### カスタムコマンド
カスタムコマンドに関する説明  
[カスタムコマンド](custom_commands.md "custom_commands.md")  

### リプライ
リプライに関する説明  
[リプライ](replies.md "replies.md")  

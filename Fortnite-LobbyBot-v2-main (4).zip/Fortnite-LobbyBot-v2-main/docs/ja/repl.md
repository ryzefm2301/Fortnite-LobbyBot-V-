## Repl.itでのボットの初回起動までの手順
しばらくお待ちください...  
~~[動画での解説]()~~  

まず[Repl.it](https://repl.it "repl.it")にアクセスします  
アカウントを作成していない場合は右上の`Sign up`、既に作成している場合は`Log in`を押しアカウントにログインします  
(アカウントの作成方法やメールアドレスの取得方法については説明しません)  

![Repl.it](https://user-images.githubusercontent.com/53356872/103261666-a173ee80-49e5-11eb-9ed3-314a469c29d2.png)  

ログインすると以下のような画面になると思うので、右上の+マークを押し  
出てきた画面で`Import From Github`を押します  
`Paste any repository URL`に`https://github.com/gomashio1596/Fortnite-LobbyBot-v2`を貼り付け、下の`Import from Github`ボタンを押します  

![Repl.it](https://user-images.githubusercontent.com/53356872/103262347-0defed00-49e8-11eb-9463-ebacf3370aab.png)  

ページが切り替わったら (このページを`プロジェクトページ`と呼びます)  
画面上部の`Run`ボタン (スマホの場合は右下の三角のボタン)  
を押し、`Console`タブでボットが起動するまで待ちます (結構時間がかかります)  
`Console`タブのことをログやコンソールと呼びます  
起動したら右上 (スマホの場合はページ下部の`Web`タブを開いて右上)  
の`Open in a new tab`を押します  
(この時開かれるページをWebページと呼びます)  

![Repl.it](https://user-images.githubusercontent.com/53356872/103263729-06324780-49ec-11eb-9b3f-f1eafcb4b17b.png)  

ページが開かれたらボットの[セットアップ](setup.md#セットアップの手順 "setup.md")に進んでください  
